# PicoHA (Pico Host Adapter)

Simple host adapter based on RP2040 (RaspberryPi Pico) for the various application:

- IO control

Each application need its specific firmware.


## Pinout

The pinout of the board

![](img/raspberry-pi-pico-pinout.png)

