# from .driver_aapicoclone_twi_master import DriverAardvarkPicoCloneTwiMaster
from .driver_picoha_io import DriverPicohaIO

PZA_DRIVERS_LIST=[
    DriverPicohaIO
]

