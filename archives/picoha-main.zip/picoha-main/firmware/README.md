#

```bash
pip install pyudev pyserial


```




## Serial Proctol




