from .driver_aapicoclone_twi_master import DriverAardvarkPicoCloneTwiMaster

PZA_DRIVERS_LIST=[
    DriverAardvarkPicoCloneTwiMaster    
]

